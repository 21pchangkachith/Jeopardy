java -jar Jeopardy.jar
